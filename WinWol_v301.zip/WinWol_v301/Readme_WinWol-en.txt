------------------------------------------------------------------------------
Wake on LAN for Windows Ver.3.01

PC launcher support Wake on LAN 
(get MAC address, IP address with acquisition function)

                             Copyright(C) 2013-2019 GUSUKU All Rights Reserved
------------------------------------------------------------------------------
                                                      Last updated�F2019/10/17

[Overview]

This software was created to launch the target host by sending a magic packet 
to a host of support Wake on LAN.

The display lists the host, we are able to check the activation status.

In addition to sending a magic packet, have the ability to get the MAC address
from the host name or IP address.

[Operating Environment]

Windows XP, Windows Vista, Windows 7, Windows 8.1, Windows 10
(I think maybe, and also work WindowsVista)

[Configuration file]

The following files are generated when you extract the archive.

    WinWol.exe                  Program file
    active.bmp                  A running icon bitmap file(16x16)
    inactive.bmp                A not running icon bitmap file(16x16)
    active-sample-32x32.bmp     A running icon bitmap file sample(32x32)
    inactive-sample-32x32.bmp   A not running icon bitmap file sample(32x32)
    Readme_WinWol.txt           Document file written in Japanese.
    Readme_WinWol-en.txt        This file

Note:
    This file was converted to English using google translation the 
    Readme-WinWol.txt written in Japanese.

[Installation]

Please put in the appropriate folder WinWol.exe.
You do not need special installation.

[Uninstall]

I just remove the (WinWol.exe) files placed.

[How to use]

  [When used as a GUI application]
    To use it as a GUI application, start it by double-clicking WinWol.exe.

  [When used as a command line application]
    To use it as a command line app without using the GUI, start it from the
    command prompt with the /C parameter.

    The start parameters are as shown in Format 1 to Format 5 below.

	The keywords / C, / H, / I, / N, / M, / B in the format will work even if
	-C, -H, -I, -N, -M, -B are specified.
	The above keywords are not case sensitive.

  Format1:
    WinWol /C /H hostname [/I IpAddress] [/N NetMask] [/M MacAddress] [/B]

  Format2:
    WinWol /C /I IPAddress [/N NetMask] [/M MacAddress] [/B]

  Format3:
    WinWol /C /M MacAddress [/I IPAddress] [/N NetMask] [/B]

  Format4:
    WinWol /C [/V]

  Format5:
    WinWol /V

  Explanation of Format 1:
    "hostname" is the host name registered on the GUI screen, and [] can be
    omitted.
    If the parameter in [] is omitted, the one corresponding to the registered
    host name is used.

    "IpAddress" is the IP address of the destination, and you can specify an 
    address different from the registered one. 
    (A broadcast address can also be specified.)

    "NetMask" is the destination netmask and is used to generate a broadcast 
    address.
    You can specify a different netmask than the one registered.

    "MacAddress" is the destination host's MAC address.
    You can also specify a different MAC address than that registered in the
    list.

    If "/B" is specified, a magic packet is sent to the target IP address 
    without using the broadcast address.
    In this case, the broadcast address is not generated using the netmask.

  Explanation of Format 2:
    "IpAddress" is the IP address of the host registered on the GUI screen, and
    the items in [] can be omitted.
    If the parameter in [] is omitted, the one corresponding to the registered
    IP address is used.

    "NetMask" is the destination netmask and is used to generate a broadcast
    address.
    You can also specify a different netmask than that registered in the list.

    "MacAddress" is the destination host's MAC address.
    You can also specify a different MAC address than that registered in the
    list.

    If "/B" is specified, a magic packet is sent to the target IP address
    without using the broadcast address.
    In this case, the broadcast address is not generated using the netmask.

  Explanation of Format 3:
    Even unregistered hosts can send magic packets in this format.

    "MacAddress" is the destination host's MAC address.

    "IpAddress" is the destination IP address.
    If the IP address is omitted, a broadcast address is generated from the IP
    address of the local host.

    "NetMask" is the destination netmask and is used to generate a broadcast
    address.
    If the netmask is omitted, the address class is obtained from the address
    of the local host, and the broadcast address is created from it.

    If "/B" is specified, a magic packet is sent to the target IP address
    without using the broadcast address.
    In this case, the broadcast address is not generated using the netmask.

  Explanation of Format 4:
    Usage is displayed at the command prompt.
    The usage is displayed even if the parameters after /C are incorrect.
    If /V is specified, only the version number is displayed.
    (There is a problem that you cannot return to the prompt unless you press
    Enter after it is displayed.)

    The display contents are as follows.

    Usage:
    ---------+---------+---------+---------+---------+---------+---------+
    Command Format:
    WinWol /C /H Hostname [/I IpAddr] [/N NetMask] [/M MacAddr] [/B]
    WinWol /C /I IpAddr [/N NetMask] [/M MacAddr] [/B]
    WinWol /C /M MacAddr [/I IpAddr] [/N NetMask] [/B]
    WinWol /C /V
    WinWol /V
    ---------+---------+---------+---------+---------+---------+---------+
    Parameters:
           /C         : Execute in command line
           /H Hostname: Target host name registered in the host list
           /I IpAddr  : Target IP address (or broadcast address)
           /N NetMask : Net mask for target network
           /M MacAddr : Target MAC address
           /B         : Do not use broadcast(Use broadcast by default)
           /V        : Disp Program Version in console
    ---------+---------+---------+---------+---------+---------+---------+
           If there is no parameter, it will start as a GUI application

  Explanation of Form 5:
    The version number is displayed.
    (There is a problem that you cannot return to the prompt unless you press
    Enter after it is displayed.)

  [note]
    To obtain the exit code with ERRORLEVEL after executing the command, start
    it with the /wait option to the start command.
    If you run WinWol.exe directly, ERRORLEVEL will always be 0.

  Example: (When an unregistered host is specified)
    C:\> start "" /wait WinWol /C /H hogehoge
    C:\> echo %ERRORLEVEL%
    -1
    C:\>

  Example: (When used in a batch file)
	@echo off
    start "" /wait /b c:\Program Files\WinWol" -c -h hogehoge
    if %ERRORLEVEL% neq 0 goto error
    goto end
    :error
	echo exitcode is %ERRORLEVEL%
	:end

  It seems that it doesn't work well if you don't specify the first parameter
  (title) of the start command (it can be an empty string).

[Explanation of screen]

  [File] menu
     [Export Host List]
       Outputs the list of displayed hosts to the specified file in CSV format.

     [Import Host List]
       Import the list of hosts from the exported CSV file.

     [End of the program]
       I exit the program.

  [Edit] menu

     [Add]
       I want to add the host information.
       Display the setting dialog editing, we add the host information at the
       end of the list.

     [Insert]
       I insert the host information.
       Display the setting dialog editing, we add the host information to the
       selected row in the list.

     [Edit]
       I will edit the host information.
       Display the setting dialog editing, we edit the host information of the
       selected row in the list.

     [Remove]
       I remove the host information.
       Display the setting dialog editing, we remove the host information of 
       the selected row in the list.
       Accelerator key "Delete" has been assigned.

     [Cut]
       It will cut the host information.
       The host information of the selected row in the list to be copied to the
       clipboard, and then deleted from the list.
       Accelerator keys "Ctrl + X" has been assigned.

     [Copy]
       It will copy the host information.
       It will copy the host information in the selected row of the list to the
       clipboard.
       Accelerator keys "Ctrl + C" has been assigned.

     [Paste]
       Paste the host information.
       The host information that is copied to the clipboard, paste it into the
       list.
       And pasted host information, the list is the case of the selected state
       is inserted into the top of the first line that has been selected, if
       the list is not selected state, is added to the end of the list.
       Accelerator keys "Ctrl + V" has been assigned.

     [Select All]
       Select all the rows of Host List.
       Accelerator keys "Ctrl + A" has been assigned.

     [Cancel Select]
       Cancels the host list selection.
       Accelerator keys "Esc" has been assigned.

     [Move Up]
       Move one line up the selected host information.
       Accelerator keys "Ctrl + U" has been assigned.

     [Move Down]
       Move one line down the selected host information.
       Accelerator keys "Ctrl + D" has been assigned.

  [View] menu

     [Refresh]
       We will update the display startup status of the host in the list.
       We will determine the response to send ICMP packet to all hosts in the
       list.
       You can set the option to wait for the response of the ICMP packet, 
       which will be described later.
       Accelerator keys "Ctrl + R" has been assigned.

     [Active Check]
       Activation status of the host to update the display of the selected row
       in the list.
       We will make sure to send ICMP response packet to the selected host in
       the list.
       You can set the option to wait for the response of the ICMP packet, 
       which will be described later.
       Accelerator keys "Ctrl + P" has been assigned.

     [Auto Refresh Start]
       I refresh process is repeated periodically.
       You can set the update interval in the options described below.

     [Auto Refresh Stop]
       I will stop processing the periodic refresh.

     [Move To Center]
       Move the window to the center of the screen.
       Accelerator keys "Ctrl + M" has been assigned.
       When a window can't be operated by moving out of the screen, by pressing
       the Ctrl + M, you can move the window in the center.
       Accelerator keys are used after the program to the active state in the 
       taskbar icon.

     [Reset To Default Size]
       Return the size and column width of the window to the default settings.
       Accelerator keys "Ctrl + S" has been assigned.

  [Tool] menu

     [Wake Up]
       By sending a magic packet, it attempts to boot from the selected host.
       Packet to be transmitted, in a UDP packet destined for the port that is
       specified in the option set, the destination IP address is the broadcast
       address to the network.
       Broadcast address is created from the IP address and net mask that is 
       set to the list.

     [Wake Up (No Broadcast)]
       By sending a magic packet, it attempts to boot from the selected host.
       Packet to be transmitted is a UDP packet destined port specified by the
       option setting, the destination address is the IP address configured in
       the list.
       Broadcast is not performed.

     [Get IP Address]
       I want to display a dialog to obtain an IP address.
       Get IP address in the dialog, we retrieve and display the IP address 
       based on the host name entered.

     [Get MAC Address]
       I get MAC address displays a dialog.
       Get MAC address in the dialog, we retrieve and display MAC address 
       based on the IP address or host name you enter.

     [Get Host Name]
       I get the host name to display the dialog.
       Gets the host name in the dialog, we are to retrieve and display the
       host name based on the IP address that you entered.

     [Send ICMP]
       I want to display the ICMP packet transmission dialog.
       The ICMP packet transmission dialog, it sends an ICMP packet to the host
       with the IP address or host name that you entered, and displays status
       as the presence or absence of the response.

     [Collect host information]
       It will collect the host of information running in the local network.
       The host information will be collected by receiving the reply by sending
       ICMP.
       To display a dialog to specify a range of addresses to send ICMP, if you 
       start by setting, and sends the ICMP packet to all of the address of the
       range that has been set.
       IP address and MAC address of the response there was the host, and then
       add the host name (if available) to the list of host information.

  [Option]
       I want to display the Option dialog box.
       Option dialog box, set the following items.
         1. Response timeout ICMP
           Specifies the time, in milliseconds, the response timeout ICMP.
           To confirm the response by sending ICMP packets to check the 
           activation status, I will not come if a response is no response and
           wait for the time specified here.
           In order to send the ICMP to all hosts in the list, the display
           update time during start-up and will take much time to update start
           and wait for the response is long.

         2.Max number of regist host
           We will specify the maximum number of hosts that can be registered
           in the list.
           I have done and update the configuration file based on this number.

         3.Destination port number
           I want to specify the port number to send the magic packet.
           Port number does not have any significance, I usually specify 0.

         4.At the start check the active status of the host in list.
           Selected at the start of the program, send an ICMP to all hosts in
           the list, whether or not to check the activation status.
           Program start-up is faster and that if you have a large number of 
           hosts in the list should be set to OFF to check.

         5.Do not use the external command
           Instead of using the command PING.EXE when checking the activation
           state of the host, and to receive a response by sending an ICMP 
           packet with RAW socket.
           In this case, since become an error if a user in the administrator
           group from the constraints of Windows, the need to run in the
           administrator group.
           Check if you can not use PING.EXE command for some reason.

         6.Check before sending the magic packet to other network.
           When sending a magic packet to the network other than the local, and
           to display a message for confirmation.

         7.Enable Auto Refresh
           Check when you update the startup state of the host at a certain 
           period.
           The period of the automatic update I is specified in seconds in the
           "Auto refresh interval" column.

         8.Show active mark in the icon
           Select to display the mark of running on icon.
           The bit map of 24-bit color 16 X 16 pixels, when placed in the same
           folder as the executable file with the following file name, you can
           change the operation in mark icon.
             'inactive.bmp'    icon bit map of the state that is not running
             'active.bmp'      icon bitmap of the state that is running

           Bitmap created in sizes other than 16x16 can be used by reducing
           the 16x16.

         9.Show active mark in a text
           Select to display the mark of running on character.
           Characters and character color to be displayed, you can specify the
           background color.

        10.Display an icon in the task tray
           To specify whether to display the icon in the task tray.
           In the task tray icon, you can select in the context menu as "the 
           center of the screen to display" and "return to the default size" 
           and "application Exit".

        11.Do not use broadcast by default when sending magic packets.
           If you check this box, broadcasts will not be used for sending magic
           packets when you double-click the first column of the host list.

  [Edit Host] Dialog
       In the Edit Host dialog, I set the following items.
         1. Host Name
           I want to specify the host name that is registered in the list.
           When you press the [GET] button, pop up a dialog for the host name
           acquisition, you can get the host name from the IP address that you
           entered.

         2. Comment
           I specify a comment for the host.

         3.IP address
           I specify the IP address of the host.
           When you press the [GET] button, pop up a dialog for IP address 
           acquisition, you can get the IP address from you enter the host name.

         4. Netmask
           I specify the netmask.
           If you enter an IP address, we seek to set the netmask from the 
           address class.

         5.MAC Address
           I specify the MAC address of the host.
           When you press the [GET] button, pop up a dialog for the MAC address 
           acquisition, you can get the MAC address from the entered IP address 
           or host name.


  [Configuration file] WinWol.ini
    Configuration file is automatically generated by the named WinWol.ini in
    the same folder as the WinWol.exe.

        It describes the items in WinWol.ini below.

        [SETTING]           ;Setting section
        PORT_NO=7                       ;Option: Packet destination port number
        ICMP_TIME_OUT=300               ;Option: ICMP response timeout
        COLLECT_HOST_ICMP_TIME_OUT=10   ;ICMP timeout at the time of the host 
                                        ;information collection
        MAX_HOST_NUM=100                ;Option: The maximum registration number
                                        ;of hosts
        LIST_ROW_HEIGHT=20              ;1 line of the height of the list
                                        ;(can be changed)
        AUTO_REFRESH=1                  ;Option: Enable Auto Refresh
        ENABLE_REMOTE_SHUTDOWN=0        ;Enable the Windowss remote shutdown
        TIMER_INTERVAL=60               ;Option: Auto refresh interval
        INIT_REFRESH=1                  ;Option: At the start check the active
                                        ;status of the host in list.
        NO_EXTERNAL_COMMAND=0           ;Option: Do not use the external command
        CHECK_NETWORK_SEGMENT=0         ;Option: Check before sending the magic
                                        ;packet to other network.

        ACTIVE_MARK_TYPE=0              ;Option: Running in the display type 
                                        ;(0=icon 1=character)
        ACTIVE_IMG_MASK_COLOR=#0000FF   ;The mask of the icon image color 
                                        ;(the color of the transparent portion
                                        ;of the bitmap)
        ACTIVE_MARK_TEXT_COLOR=#000000  ;Option: Active mark Text Color
        ACTIVE_MARK_BACK_COLOR=#00FF00  ;Option: Active mark Back Color
        ACTIVE_MARK_TEXT=" *"           ;Option: Active mark Text
        DEFAULT_HOST=15                 ;Seletced host(It choose at startup)
        TASK_TRAY_ICON=1                ;Option: Display an icon in the task tray.
                                        (0=Not Display 1=Display)
        NON_BROADCAST_DFLT=0            Whether to use broadcast when sending 
                                        magic packet with double click.
                                        (0=Use Broadcast 1=Not Use Broadcast)

        [WINDOW]            ;Window position and size, column width (Auto)
        WINDOW_X=1032               ;X position of the window
        WINDOW_Y=139                ;Y position of the window
        WINDOW_WIDTH=730            ;Width of the window
        WINDOW_HEIGHT=498           ;Height of the window
        ITEM_WIDTH_BOOT=45          ;Column width of the Active mark
        ITEM_WIDTH_HOST_NAME=111    ;Column width of the host name
        ITEM_WIDTH_COMMENT=181      ;Column width of the comment
        ITEM_WIDTH_IP_ADDR=108      ;Column width of the IP address
        ITEM_WIDTH_NET_MASK=108     ;Column width of net mask
        ITEM_WIDTH_MAC_ADDR=129     ;Column width of the MAC address

        [HOST_0]            ;Host registration information (line 1)
        HOST_NAME=www                   ;Host name
        IP_ADDR=192.168.1.1             ;IP address
        NET_MASK=255.255.255.0          ;Net mask
        MAC_ADDR=12:34:AB:CD:56:EF      ;MAC address
        COMMENT=Main Server             ;Comment

        [HOST_1]            ;Host registration information (line 2)
        HOST_NAME=www2
        IP_ADDR=192.168.1.2
        NET_MASK=255.255.255.0
        MAC_ADDR=AB:CD:12:34:56:EF
        COMMENT=Spare server

        [HOST_2]            ;Host registration information (line 3)
        HOST_NAME=work-pc
        IP_ADDR=192.168.1.3
        NET_MASK=255.255.255.0
        MAC_ADDR=00:12:34:56:AB:CD
        COMMENT=The work PC

            :
            :
            :
            :

[Update History]
    Ver.3.01  2019/10/17
        Added a parameter to start as a command line application.

    Ver.3.00  2019/09/19
        Since exclusive control of the host list was incomplete, exclusive 
        control processing was added to the part for editing host information.

        Added host list export and host list import.

        In the case of setting to use an external command (ping), the exit code
        check method has been changed because the exit code of the ping command
        may be 0 (normal termination) even on a host that is not running.
        (Fixed to check ping output with find command)

        Added the number of registrations and selections to the items displayed
        on the status bar

        The progress status during operation status update is displayed in the 
        status bar.

        Added the sorting function of the host list.
        (Sort by clicking the column header)

        Added a setting to disable broadcasts when sending magic packets by 
        double-clicking in the option settings.

        Added non-broadcast magic packet transmission to the toolbar.

        In host information editing, when acquiring an IP address from a host
        name, ARP transmission was performed to acquire a MAC address, but it
        was not performed.

        Added deselection menu.

        Fixed menu and tooltip controls.

    Ver.2.09  2017/09/01
        When automatic update was enabled, the program ended abnormally when
        editing the host list, so updating of the host information was stopped
        until editing was completed.

    Ver.2.08  2016/08/21
        If the window has been completed while out of the screen, or added to in
        the case of at the end of the coordinates can not be acquired normally, 
        by the accelerator key as "screen display in the center" and "return to 
        the default size." .

        As a precaution, to display the task tray icon, it was to allow the 
        operation of the above in the context menu.(It can be enabled in the 
        options settings)

        If the application window is out of the screen at the time of the end, 
        from the fix to fit the position of the window on the screen, it has to 
        be stored in the configuration file.

    Ver.2.07  2016/01/07
        When automatic updating is turned ON, because the course display update
        of host information collection there was a case to stop, we fix this.

        Setting the start IP address and end IP address and MAC address of the
        host information collection dialog to save the configuration file, it
        was to be used as a default value at the time of the next host
        information collection.

        To start from the Tools menu in the dialog's "Get IP Address",
        "Get MAC Address" "Get Host Name" "Send ICMP", the host of the
        information in selected in the host list, it has to be set as the
        default value.

    Ver.2.06  2015/10/04
        Start (No Broadcast) to add the menu, we have to be able to send magic
        packets that do not use the broadcast.

    Ver.2.05  2015/07/31
        Between the update thread and the main thread, because conflict of
        data update was there that the crash occurred, and we strengthened
        our exclusive control.

    Ver.2.04  2015/07/03
        Fixed a bug that crashes when you change the type of active mark in the
        Options dialog.
        In Windows 8.1 and Windows 10 (insider preview), it was confirmed that
        it works correctly.

    Ver.2.03  2015/06/11
        Fixed because tool tip of the button that you added to the toolbar is
        not out.

    Ver.2.02  2015/06/11
        In the Edit host information, it was corrected because there was a bug
        that content is not saved.

    Ver.2.01  2015/06/10
        Add the function of copy and paste using the clipboard.
        Keyboard accelerator is now available.

    Ver.2.00  2015/06/04
        Add the host information collection function
        The state of the running was so you can choose to either of the icon
        display or character display.
        The process of updating the state of running was changed to perform a
        background thread
        Line of host information becomes movable in the vertical.
        It was to send the magic packet When you double-click on the first item
        of the line.

    Ver.1.0.2.0 2013/10/06
        In the non-administrative users, because it is an error when sending an
        ICMP packet in the startup check of the host, regular users as well as
        can be used, and to use the PING.EXE command to verify the host.

        It is able to change not PING.EXE, to use ICMP to add the configuration
        that does not use external command option.

        Add an ICMP packet transmission dialog.

    Ver.1.0.1.0 2013/01/26
        Initial release

[Terms of Use]

Terms of Use
     There are no special conditions. Please use freely.
     However, unless we are to be used for that crime or harm to others.

For distribution
     Redistribution in the state that has not been edited or modifications 
     (source code) is free.

     (If the source code) for editing and modification
     Changes or modifications can be carried out freely, but, if you want to 
     redistribute those changes, you need to include in the distribution 
     document that clearly states the changes.

     If you want to use other software part of the source code for this 
     software is that it does not apply.

And Disclaimer
     I have been caused by the use of this software, and what the author is not
     responsible for any failure, for whatever damages.

     The authors assumed that even in the case of this software bug is found,
     correct them and not assume the obligation of version up

For requests Bug
     For bugs and requests, please email.
     However, this does not necessarily mean a guaranteed bug fixes, is 
     reflected in the demand.

Information Copyright:
     The copyright of this software is owned by the author is GUSUKU there.
     This software is protected by international copyright laws and treaties.
     The grant to be used within the scope of the Acceptable Use Policy, use in
     violation of the Acceptable Use Policy, and make and distribute, please 
     note it will be copyright infringement.

[Contact]
     GUSUKU
     root@gusuku.org

------------------------------------------------------------------------------
